#include <stdlib.h>
#include <stdio.h>

/*
typedef struct climber{
	int *LH;
	int *RH;
	int *LF;
	int *RF;
} climber;
*/

int legal_position(int A, int T, int L, int *coords);
